App({
    onLaunch() {
      // 初始化时加载简历数据
      this.loadResumeData();
    },
    
    // 加载简历数据
    loadResumeData() {
      try {
        const resumeData = wx.getStorageSync('resumeData');
        this.globalData.resumeData = resumeData || {};
        return resumeData;
      } catch (e) {
        console.error('加载简历数据失败', e);
        return {};
      }
    },
    
    // 保存简历数据
    saveResumeData(data) {
      try {
        wx.setStorageSync('resumeData', data);
        this.globalData.resumeData = data;
        return true;
      } catch (e) {
        console.error('保存简历数据失败', e);
        return false;
      }
    },
    
    globalData: {
      resumeData: {}
    }
  });