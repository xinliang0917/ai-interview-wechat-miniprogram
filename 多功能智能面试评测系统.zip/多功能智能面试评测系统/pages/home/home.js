Page({
    data: {
        isLoggedIn: true, // 直接设为已登录
        showMask: false,  // 隐藏遮罩层
    //    isLoggedIn: false, // 用户是否已登录
    //    showMask: true, // 控制遮罩层显示
    },
  
    onLoad() {
      // 检查用户是否已登录
      this.checkLoginStatus();
    },
  
    // 检查登录状态
    checkLoginStatus() {
      const userInfo = wx.getStorageSync('userInfo');
      if (userInfo) {
        this.setData({ isLoggedIn: true ,
        showMask: false });
      }
     },
  
    // 处理登录点击事件
    handleLogin() {
      wx.showLoading({
        title: '登录中...',
        mask: true
      });
      
      wx.login({
        success: (res) => {
          if (res.code) {
            // 将code发送到后端换取用户信息
            wx.request({
              url: 'https://your-api.com/login', // 替换为实际的登录API
              method: 'POST',
              data: { code: res.code },
              success: (result) => {
                if (result.data.code === 0) {
                  // 登录成功，保存用户信息到本地存储
                  wx.setStorageSync('userInfo', result.data.data);
                  this.setData({ isLoggedIn: true , showMask: false});
                  wx.hideLoading();
                  wx.showToast({
                    title: '登录成功',
                    icon: 'success'
                  });
                } else {
                  wx.hideLoading();
                  wx.showToast({
                    title: result.data.msg || '登录失败',
                    icon: 'none'
                  });
                }
              },
              fail: () => {
                wx.hideLoading();
                wx.showToast({
                  title: '登录失败',
                  icon: 'none'
                });
              }
            });
          } else {
            wx.hideLoading();
            wx.showToast({
              title: '获取登录凭证失败',
              icon: 'none'
            });
          }
        },
        fail: (err) => {
          wx.hideLoading();
          wx.showToast({
            title: '登录调用失败：' + err.errMsg,
            icon: 'none'
          });
        }
      });
 },
  
    // 跳转到下一页
    gotoNextPage() {
      if (this.data.isLoggedIn || !this.data.showMask) {
        // 已登录，跳转到相应页面
        wx.navigateTo({
          url: '/pages/report/report' // 替换为实际的页面路径
        });
      } else {
        // 未登录，提示用户先登录
        wx.showToast({
          title: '请先登录',
          icon: 'none'
        });
      }
    }
  });