Page({
    data: {
      name: '',
      baseInfos: ['', '', ''], // 学历、年龄、院校
      analysisCount: 0,
      doneCount: 0,
      expectation: '',
      advantage: '',
      awards: ['', ''],
      educations: ['', ''],
      works: ['', ''],
      userInfo: {},
      isLoggedIn: true, // 用户是否已登录
      showMask: false, // 控制遮罩层显示
    },
  
    onLoad() {
      this.loadResumeData();
      this.getUserInfo();
      this.checkLoginStatus();
    },
    
    // 检查登录状态
    checkLoginStatus() {
      const userInfo = wx.getStorageSync('userInfo');
      if (!userInfo) {
        this.setData({
          isLoggedIn: false
        });
        
        // 如果是从登出跳转过来的，不重复跳转
        const currentPages = getCurrentPages();
        if (currentPages.length === 1 && currentPages[0].route === 'pages/person/person') {
          console.log('已在个人中心页面，不重复跳转');
          return;
        }
        
        // 跳转到登录页
        wx.navigateTo({ url: '/pages/login/login' });
      }
    },
  
    loadResumeData() {
      try {
        const resumeData = wx.getStorageSync('resumeData');
        if (resumeData) {
          this.setData(resumeData);
        }
      } catch (e) {
        console.error('加载简历数据失败', e);
      }
    },
  
    getUserInfo() {
      try {
        const userInfo = wx.getStorageSync('userInfo');
        if (userInfo) {
          this.setData({ userInfo });
        }
      } catch (e) {
        console.error('获取用户信息失败', e);
      }
    },
  
    onNameChange(e) {
      this.setData({ name: e.detail.value });
    },
  
    onBaseInfoChange(e) {
      const index = e.currentTarget.dataset.index;
      const value = e.detail.value;
      const baseInfos = this.data.baseInfos;
      baseInfos[index] = value;
      this.setData({ baseInfos });
    },
  
    onExpectationChange(e) {
      this.setData({ expectation: e.detail.value });
    },
  
    onAdvantageChange(e) {
      this.setData({ advantage: e.detail.value });
    },
  
    onAwardChange(e) {
      const index = e.currentTarget.dataset.index;
      const value = e.detail.value;
      const awards = this.data.awards;
      awards[index] = value;
      this.setData({ awards });
    },
  
    onEducationChange(e) {
      const index = e.currentTarget.dataset.index;
      const value = e.detail.value;
      const educations = this.data.educations;
      educations[index] = value;
      this.setData({ educations });
    },
  
    onWorkChange(e) {
      const index = e.currentTarget.dataset.index;
      const value = e.detail.value;
      const works = this.data.works;
      works[index] = value;
      this.setData({ works });
    },
  
    chooseAvatar() {
      wx.chooseAvatar({
        success: (res) => {
          const userInfo = this.data.userInfo;
          userInfo.avatarUrl = res.avatarUrl;
          this.setData({ userInfo });
          wx.setStorageSync('userInfo', userInfo);
        }
      });
    },
  
    // 添加获奖项
    addAward() {
      const awards = this.data.awards;
      awards.push('');
      this.setData({ awards });
    },
  
    // 添加教育经历
    addEducation() {
      const educations = this.data.educations;
      educations.push('');
      this.setData({ educations });
    },
  
    // 添加工作经历
    addWork() {
      const works = this.data.works;
      works.push('');
      this.setData({ works });
    },
  
    saveResume() {
        // 构建简历数据对象
        const resumeData = {
          name: this.data.name,
          baseInfos: this.data.baseInfos,
          expectation: this.data.expectation,
          advantage: this.data.advantage,
          awards: this.data.awards.filter(item => item.trim() !== ''),
          educations: this.data.educations.filter(item => item.trim() !== ''),
          works: this.data.works.filter(item => item.trim() !== '')
        };
        
        try {
          // 存储数据
          wx.setStorageSync('resumeData', resumeData);
          
          // 方案1：直接加1
          // this.setData({ doneCount: this.data.doneCount + 1 });
          
          // 方案2：智能计算字段数量（推荐）
          const filledFields = [
            resumeData.name,
            ...resumeData.baseInfos,
            resumeData.expectation,
            resumeData.advantage,
            ...resumeData.awards,
            ...resumeData.educations,
            ...resumeData.works
          ].filter(value => value && value.trim() !== '').length;
          this.setData({ doneCount: filledFields });
          
          wx.showToast({ title: '保存成功', icon: 'success' });
          wx.emit('resumeDataUpdated', resumeData);
        } catch (e) {
          console.error('保存失败', e);
          wx.showToast({ title: '保存失败', icon: 'error' });
        }
      },
  
    handleLogout() {
      wx.showModal({
        title: '确认登出',
        content: '确定要退出当前账号吗？',
        success: (res) => {
          if (res.confirm) {
            console.log('开始登出操作');
            
            // 移除用户信息和简历数据
            wx.removeStorageSync('userInfo');
            wx.removeStorageSync('resumeData');
            
            // 更新页面状态
            this.setData({
              isLoggedIn: false,
              showMask: true
            }, () => {
              console.log('状态更新完成:', this.data.isLoggedIn);
              
              // 判断目标页面是否为 tabBar 页面
              const tabBarPages = ['pages/home/home', 'pages/discover/discover', 'pages/mine/mine']; // 根据你的 app.json 配置修改
              const targetUrl = '/pages/home/home';
              
              if (tabBarPages.includes(targetUrl.replace(/^\//, ''))) {
                // 是 tabBar 页面，使用 switchTab
                wx.switchTab({
                  url: targetUrl,
                  success: () => {
                    console.log('跳转到首页成功');
                  },
                  fail: (err) => {
                    console.error('switchTab 跳转失败:', err);
                    // 备选方案：跳转到非 tabBar 页面
                    wx.navigateTo({ url: '/pages/home/home' });
                  }
                });
              } else {
                // 不是 tabBar 页面，使用 redirectTo
                wx.redirectTo({
                  url: targetUrl,
                  success: () => {
                    console.log('跳转到目标页面成功');
                  },
                  fail: (err) => {
                    console.error('redirectTo 跳转失败:', err);
                    // 备选方案：跳转到其他页面
                    wx.navigateTo({ url: '/pages/home/home' });
                  }
                });
              }
            });
          }
        }
      });
    }
  });