// pages/seeing/seeing.js
Page({
    data: {
      jobId: null,
      jobData: null
    },
  
    onLoad(options) {
      if (options.id) {
        this.setData({ jobId: options.id });
        this.fetchJobDetail(options.id);
      }
    },
  
    // 获取职位详情
    fetchJobDetail(jobId) {
      // 实际项目中这里会调用API获取数据
      const mockData = {
        id: parseInt(jobId),
        jobName: "互联网产品经理",
        tag: "最新",
        date: "2025.6.23",
        matchRate: "匹配度 86.6%",
        description: "负责公司互联网产品的规划与设计，推动产品迭代优化...",
        requirements: "本科及以上学历，3年以上产品经验，具备良好的数据分析能力..."
      };
      this.setData({ jobData: mockData });
    }
  });