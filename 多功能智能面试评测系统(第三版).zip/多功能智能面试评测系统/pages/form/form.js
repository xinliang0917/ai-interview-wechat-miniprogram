Page({
    data: {
      position: '', // 应聘岗位
      answerTypes: ['请选择回答形式', '视频回答', '文字回答', '语音回答', '现场面试'],
      answerTypeIndex: 0,
      fileInfo: null,       // 选择的文件对象
      fileUploaded: false   // 是否已上传成功
    },
  
    onLoad() {
      console.log('Form page loaded');
      if (!getApp().globalData) {
        getApp().globalData = {};
      }
    },
  
    onPositionInput(e) {
      this.setData({ position: e.detail.value });
    },
  
    onAnswerTypeChange(e) {
      this.setData({
        answerTypeIndex: Number(e.detail.value)
      });
    },
  
    uploadFile() {
      wx.chooseMessageFile({
        count: 1,
        type: 'all',
        success: res => {
          const file = res.tempFiles[0];
          console.log('选择的文件:', file);
  
          this.setData({
            fileInfo: file,
            fileUploaded: true
          });
  
          wx.uploadFile({
            url: 'https://your-server/upload', // 换成你的实际服务器地址
            filePath: file.path,
            name: 'file',
            formData: { user: 'demo-user' },
            success: uploadRes => {
              console.log('上传成功:', uploadRes);
              wx.showToast({ title: '上传成功', icon: 'success' });
            },
            fail: err => {
              console.error('上传失败:', err);
              wx.showToast({ title: '上传失败', icon: 'none' });
              this.setData({ fileUploaded: false });
            }
          });
        },
        fail: err => {
          console.error('选择文件失败:', err);
          wx.showToast({ title: '选择文件失败', icon: 'none' });
        }
      });
    },
  
    navigateToReport() {
      const { position, fileInfo, answerTypeIndex, answerTypes } = this.data;
  
      if (!position) {
        wx.showToast({ title: '请输入应聘岗位', icon: 'none' });
        return;
      }
  
      if (answerTypeIndex === 0) {
        wx.showToast({ title: '请选择回答形式', icon: 'none' });
        return;
      }
  
      const applicationData = {
        position,
        resumeUrl: fileInfo ? fileInfo.path : '',
        answerType: answerTypes[answerTypeIndex]
      };
  
      getApp().globalData.applicationData = applicationData;
  
      wx.navigateTo({
        url: '/pages/report/report'
      });
    }
  });
  